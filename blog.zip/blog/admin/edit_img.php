<?php
        $view  = "edit_img";
        include("template.php");
?>