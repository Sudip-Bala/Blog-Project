<?php
        $view  = "add_category";
        include("template.php");
?>