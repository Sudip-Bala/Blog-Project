<?php
        $view  = "edit_post";
        include("template.php");
?>