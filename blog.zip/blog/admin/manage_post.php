<?php
        $view  = "manage_post";
        include("template.php");
?>