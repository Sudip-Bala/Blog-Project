<?php
        $view  = "dashboard";
        include("template.php");
?>