<?php
        $view  = "add_post";
        include("template.php");
?>