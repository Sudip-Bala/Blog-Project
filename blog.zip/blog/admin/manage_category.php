<?php
        $view  = "manage_category";
        include("template.php");
?>